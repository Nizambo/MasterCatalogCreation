package com.nike.wipro;

import java.awt.Robot;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.logging.Logger;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.thoughtworks.selenium.webdriven.commands.KeyEvent;

public class UpdateAction {
	
	private static final String MasterCatalog = null;

	public static boolean loginQA(WebDriver driver){
	    driver.get("https://cdm-webapp-qa.nike.net/CDM_Web/login.do");
	    driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[2]/span[2]/input")).sendKeys("csargu");
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[3]/span[2]/input")).sendKeys("roter!solly");		
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[4]/input")).click();
		
		return true;
	}

	public static boolean loginProd(WebDriver driver){
	    driver.get("https://cdmwebapp.nikeprd.net/CDM_Web/login.do");
	    driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[2]/span[2]/input")).sendKeys("njeel1");
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[3]/span[2]/input")).sendKeys("Ni#909457");		
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[4]/input")).click();
		
		return true;
	}
	public static boolean loginStg(WebDriver driver){
	    driver.get("https://cdm-webapp-stg.nikecloud.net/CDM_Web/login.do");
	    driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[2]/span[2]/input")).sendKeys("njeel1");
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[3]/span[2]/input")).sendKeys("pwdNike5");		
		driver.findElement(By.xpath(".//*[@id='loginBox']/form/div[4]/input")).click();
		
		return true;
	}
	
	public static void createCatalog(WebDriver driver, MasterCatalogBean catalogId, Logger logger){
		
		try {
			
				
				driver.findElement(By.xpath(".//*[@id='catalogMenu']/select/option[2]")).click();
				Thread.sleep(2000);
				
				driver.findElement(By.xpath("html/body/form/div[2]/div[1]/table/tbody/tr[2]/td[2]/input")).sendKeys(catalogId.getCatalogName());				
				Thread.sleep(2000);
				Select select = new Select(driver.findElement(By.xpath("html/body/form/div[2]/div[1]/table/tbody/tr[3]/td[2]/select")));
				select.selectByVisibleText(catalogId.getCountry());
				//Thread.sleep(1000);
				Select select1 = new Select(driver.findElement(By.xpath("html/body/form/div[2]/div[1]/table/tbody/tr[4]/td[2]/select")));
				select1.selectByVisibleText(catalogId.getLanguage());
				//Thread.sleep(1000);
				Select select2 = new Select(driver.findElement(By.xpath("html/body/form/div[2]/div[1]/table/tbody/tr[5]/td[2]/table/tbody/tr[1]/td[2]/select")));
				select2.selectByVisibleText(catalogId.getStartSeason());
				//Thread.sleep(1000);
				Select select3 = new Select(driver.findElement(By.xpath("html/body/form/div[2]/div[1]/table/tbody/tr[5]/td[2]/table/tbody/tr[2]/td[2]/select")));
				select3.selectByVisibleText(catalogId.getEndSeason());
				//Thread.sleep(1000);
				Select select4 = new Select(driver.findElement(By.xpath(".//*[@id='businessUnits']")));
				select4.selectByVisibleText(catalogId.getSite());
				driver.findElement(By.xpath("html/body/form/div[2]/div[2]/div/input[2]")).click();
				Thread.sleep(3000);		
			//	driver.findElement(By.xpath("")).click();
			//	driver.findElement(By.xpath("html/body/form[2]/div/div[2]/form/div/div/input[2]")).click();
				
				logger.info(driver.findElement(By.xpath("html/body/div[3]/div/table/tbody/tr[2]/td[2]")).getText());
				logger.info(catalogId + "has been created");
				Thread.sleep(2000);
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).clear();
				Thread.sleep(1000);
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys(catalogId.getUser1());
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[3]/input")).click();
				driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr/td[1]/input")).click();  
				Thread.sleep(2000);	
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[3]/table/tbody/tr[2]/td/input")).click();
				Thread.sleep(2000);	//User 1 added (Owner)
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).clear();
				Thread.sleep(1000);
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys(catalogId.getUser2());
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[3]/input")).click();
				driver.findElement(By.xpath("//*[@id=\"searchRow\"]/tbody/tr[2]/td[1]/input")).click();  
				Thread.sleep(2000);	
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[3]/table/tbody/tr[2]/td/input")).click();
				Thread.sleep(2000);//user 2 added(Marcus Hiersche)
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).clear();
				Thread.sleep(1000);
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys(catalogId.getUser3());
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[3]/input")).click();
				driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr/td[1]/input")).click();  
				Thread.sleep(2000);	
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[3]/table/tbody/tr[2]/td/input")).click();
				Thread.sleep(2000);//user 3 added
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).clear();
				Thread.sleep(1000);
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys(catalogId.getUser4());
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[3]/input")).click();
				driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr/td[1]/input")).click();  
				Thread.sleep(2000);	
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[3]/table/tbody/tr[2]/td/input")).click();
				Thread.sleep(2000);//user 4 added
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).clear();
				Thread.sleep(1000);
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[2]/input")).sendKeys(catalogId.getUser5());
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[1]/table/tbody/tr[2]/td[3]/input")).click();
				driver.findElement(By.xpath(".//*[@id='searchRow']/tbody/tr/td[1]/input")).click();  
				Thread.sleep(2000);	
				driver.findElement(By.xpath("html/body/form[2]/div/div[1]/div[3]/div/table/tbody/tr/td[3]/table/tbody/tr[2]/td/input")).click();
				Thread.sleep(2000);//User 5 added
				
				driver.findElement(By.xpath(".//*[@id='row1']/tbody/tr[2]/td[1]/div/input")).click();
				Thread.sleep(1000);	
				driver.findElement(By.xpath("html/body/form[1]/div/div/div[3]/div/table/tbody/tr[2]/td/input[1]")).click();
				Thread.sleep(3000);	
				//driver.findElement(By.cssSelector("html/body/form/div[2]/div[1]/table/tbody/tr[3]/td[2]/select")).getCssValue("JAPAN");
				
				
				 
			} 
		catch (InterruptedException e) 
		{
				e.printStackTrace();
			}
	}
	

}
	

		
		