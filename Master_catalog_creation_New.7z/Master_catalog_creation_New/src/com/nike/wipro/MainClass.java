package com.nike.wipro;


import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import jxl.read.biff.BiffException;

public class MainClass {

	public static void main(String[] args) throws InterruptedException, SecurityException, IOException, BiffException {

		Logger  logger = Logger.getLogger("MyLog");  
	    FileHandler fh;  
	    boolean syncUpDone;
	    fh = new FileHandler("C:\\Selenium\\TestCase\\Logs\\MyLogFile.log");  
	    logger.addHandler(fh);
	    SimpleFormatter formatter = new SimpleFormatter(); 
	    fh.setFormatter(formatter); 
	   // System.setProperty("webdriver.firefox.bin","D:\\Users\\njeel1\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
	    String exePath =  "C:\\Users\\njeel1\\Documents\\seleniumjars\\seleniumjars\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);
		WebDriver driver = new ChromeDriver();
		
		//WebDriver driver = new FirefoxDriver();
		logger.info("Opened browser Successfully");
		
		//boolean loginQA = UpdateAction.loginQA(driver);
		boolean loginProd = UpdateAction.loginProd(driver);
		//boolean loginStg = UpdateAction.loginStg(driver);
		logger.info("Logged in CDM Successfully");
		Thread.sleep(3000);
		
			
		System.out.println("Opened site successfully");
		
	
		
		//List<CatalogRemovalBean> exceRecords = ReadExcel.readExcelForCatalogRemoval();
		List<MasterCatalogBean> exceRecords = ReadExcel.readExcel();
		
		
		
		for(MasterCatalogBean c:exceRecords)
		{
			
			Thread.sleep(2000);
			/*String catalogId = null;
			String startDate = null;
			String endDate = null; 
			String catalogType1 = null;*/
			
			UpdateAction.createCatalog(driver,c,logger);
			//UpdateAction.createTransCatalog(driver, catalogId, logger);
			
				}
			//driver.findElement(By.xpath("/.//*[@id='tabPanel']/ul/li[2]/a")).click(); --customers
			//driver.findElement(By.xpath("//*[@id='contentPanel']/div/div[5]/div[1]/h2/a/em")).click(); --view/edit
			//driver.findElement(By.xpath("//*[@id='contentPanel']/div/div[3]")).click();
		    //driver.findElement(By.xpath("//*[@id='tabPanel']/ul/li[4]/a")).click();
			
		  
			Thread.sleep(3000);
	//		logger.info("Invite sent successfully...."+catalogId);
			
		}
			
	//Thread.sleep(3000);
		// logger.info("I am done Nizam :-)");
	

}


