package com.nike.wipro;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.logging.Logger;

//import com.gargoylesoftware.htmlunit.javascript.host.Set;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ReadExcel {
	public static List<MasterCatalogBean> readExcel() throws BiffException,IOException {
	
		Logger  logger = Logger.getLogger("MyLog");
		FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Master_catalog1.xls"));
		//FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Trans_Catalog1.xls"));
		//System.out.println(xlfile.getAbsolutePath());
		Workbook wb = Workbook.getWorkbook(fs);
		List<MasterCatalogBean> catalogList=new ArrayList<MasterCatalogBean>();
		LinkedHashSet catalog_id = new LinkedHashSet();
	//	LinkedHashSet catalog_type= new LinkedHashSet();
		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		for (int row = 0; row < totalNoOfRows; row++) {
			
			if(row==0)
			{
				continue;
			}
			MasterCatalogBean c=new MasterCatalogBean();
			for (int col = 0; col < totalNoOfCols; col++)
				{
				System.out.print(sh.getCell(col, row).getContents() + "\t");
				catalog_id.add(sh.getCell(col, row).getContents());
				
				
				
				if(col==0)
				{
					
					c.setCatalogName(sh.getCell(col, row).getContents());
					
				}

				if(col==1)
				{
					c.setCountry(sh.getCell(col, row).getContents());
				}
				
				if(col==2)
				{
					c.setLanguage(sh.getCell(col, row).getContents());
				}
				
				if(col==3)
				{
					c.setStartSeason(sh.getCell(col, row).getContents());
				}
				if(col==4)
				{
					c.setEndSeason(sh.getCell(col, row).getContents());
				}
				if(col==5)
				{
					c.setSite(sh.getCell(col, row).getContents());
				}
				if(col==6)
				{
					c.setUser1(sh.getCell(col, row).getContents());
				}
				if(col==7)
				{
					c.setUser2(sh.getCell(col, row).getContents());
				}
				if(col==8)
				{
					c.setUser3(sh.getCell(col, row).getContents());
				}
				if(col==9)
				{
					c.setUser4(sh.getCell(col, row).getContents());
				}
				if(col==10)
				{
					c.setUser5(sh.getCell(col, row).getContents());
				}
				
			//	catalog_type.add(sh.getCell(col+1,row).getContents());
			//	System.out.print(sh.getCell(col+1, row).getContents() + "\t");
			}
			catalogList.add(c);
		}
		return catalogList;
		
				
		
				
	}
	/*
	public static LinkedHashSet readExcel2() throws BiffException,IOException {
		
		Logger  logger = Logger.getLogger("MyLog");
		//String FilePath = "C:\\Selenium\\Excel\\TestCase.xlsx";
		FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Book2.xls"));
		Workbook wb = Workbook.getWorkbook(fs);
		List<CreateUserBean> createUserList=new ArrayList<CreateUserBean>();
		LinkedHashSet catalogType = new LinkedHashSet();
		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		for (int row = 0; row < totalNoOfRows; row++) {

			for (int col = 0; col < totalNoOfCols; col++)
				{
				System.out.print(sh.getCell(col, row).getContents() + "\t");
				catalogType.add(sh.getCell(col, row).getContents());
			}
		}
		return catalogType;
				
		
				
	}
	
	public static List<CatalogRemovalBean> readExcelForCatalogRemoval() throws BiffException,IOException {
		
		Logger  logger = Logger.getLogger("MyLog");
		//String FilePath = "C:\\Selenium\\Excel\\TestCase.xlsx";
		FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Book1.xls"));
		Workbook wb = Workbook.getWorkbook(fs);
		List<CatalogRemovalBean> catalogRemovalList=new ArrayList<CatalogRemovalBean>();
		
		// TO get the access to the sheet
		Sheet sh = wb.getSheet("Sheet1");

		// To get the number of rows present in sheet
		int totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		int totalNoOfCols = sh.getColumns();

		// make sure to validate excel first
		if(totalNoOfCols == 3){
			CatalogRemovalBean crb=null;		
				for (int row = 0; row < totalNoOfRows; row++) {
					for (int col = 0; col < totalNoOfCols; col++) {
crb=new CatalogRemovalBean();
				System.out.print(sh.getCell(col, row).getContents() + "\t");
					if(col == 0){
				//		catalogName.add(sh.getCell(col, row).getContents());
						crb.setCatalogType(sh.getCell(col, row).getContents());
					}
					if(col == 1){
			//			catalogId.add(sh.getCell(col, row).getContents());
						crb.setCatalogId(sh.getCell(col, row).getContents());
					}
					if(col == 2){
						//			catalogId.add(sh.getCell(col, row).getContents());
									crb.setEndDate(sh.getCell(col,row).getContents());
									//crb.getEndDate()(sh.getCell(row, col).getContents());
								}
				}
			}
				catalogRemovalList.add(crb);
				
		}
		
				return catalogRemovalList;
	}

	public static LinkedHashSet getCatalogTypeList() throws BiffException,IOException {
		FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Book3.xls"));
		Workbook wb = Workbook.getWorkbook(fs);
		LinkedHashSet catalogType = new LinkedHashSet();
		// TO get the access to the sheet
		Sheet sh1 = wb.getSheet("Sheet1");
		
		//To get list of catalog types from sheet 1
				int totalNoOfRowsS1 = sh1.getRows();
				int totalNoOfColsS1 = sh1.getColumns();
				for (int col = 0; col < totalNoOfColsS1; col++) {
					for (int row = 0; row < totalNoOfRowsS1; row++) {
				//		catalogType.add(sh1.getCell(col, row).getContents());
					}
				}
				System.out.println("catalogType :"+catalogType);
				return catalogType;
	}
	
	public static LinkedHashMap getCatalogIDMap() throws BiffException,IOException {
		FileInputStream fs = new FileInputStream(new File("C:\\Selenium\\Excel\\Book3.xls"));
		Workbook wb = Workbook.getWorkbook(fs);
		LinkedHashMap cataloyTypeID = new LinkedHashMap();
		// TO get the access to the sheet
		Sheet sh2 = wb.getSheet("Sheet2");
		
		// To get the number of rows present in sheet
				int totalNoOfRows = sh2.getRows();

				// To get the number of columns present in sheet
				int totalNoOfCols = sh2.getColumns();

				for (int col = 0; col < totalNoOfCols; col++) {
					for (int row = 0; row < totalNoOfRows; row++) {
						if(col == 0){
					//		cataloyTypeID.put(sh2.getCell(col, row).getContents(), sh2.getCell(col+1, row).getContents());
						}
					}
				}
				System.out.println("cataloyTypeID :"+cataloyTypeID);
				return cataloyTypeID;
	}*/
	
}
